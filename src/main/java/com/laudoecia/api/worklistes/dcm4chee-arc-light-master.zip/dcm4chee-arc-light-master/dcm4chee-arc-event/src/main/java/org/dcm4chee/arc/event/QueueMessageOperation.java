package org.dcm4chee.arc.event;

/**
 * @author Vrinda Nayak <vrinda.nayak@j4care.com>
 * @since Feb 2018
 */

public enum QueueMessageOperation {
    CancelTasks,
    RescheduleTasks,
    DeleteTasks
}
